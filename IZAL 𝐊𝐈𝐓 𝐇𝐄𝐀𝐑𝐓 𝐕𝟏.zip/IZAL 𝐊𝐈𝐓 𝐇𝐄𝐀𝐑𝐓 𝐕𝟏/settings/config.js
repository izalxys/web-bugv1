
const fs = require('fs')

//---------- Setting Script -----------//
global.prefa = ['','!','.',',','🐤','🗿']
global.owner = ['6282124151716']

//---------- Setting Sticker -----------//
global.packname = "Sticker By Izal"
global.author = "Izalmarket"

//---------- Global Messenger -----------//
global.mess = {
 owner: '*You are not the owner*',
 premium: '*You are not premium*'
}

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
require('fs').unwatchFile(file)
console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
delete require.cache[file]
require(file)
})